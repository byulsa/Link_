using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public sealed class BossEnemy : MeleeEnemy
{
    [SerializeField] private SpriteRenderer visual;
    [SerializeField, Min(0f)] private float timeBetweenPatterns = 5f;
    [SerializeField, Min(0f)] private float laserDamage = 24f;
    [SerializeField, Min(0f)] private float slashDamage = 38f;
    [Header("Bonus Damage (% of Player Max HP)")]
    [SerializeField, Range(2f, 5f)] private float meleeHealthDamagePercent = 2f;
    [SerializeField, Range(2f, 5f)] private float laserHealthDamagePercent = 3f;
    [SerializeField, Range(2f, 5f)] private float slashHealthDamagePercent = 5f;
    [SerializeField, Range(0.5f, 0.75f)] private float patternDamageReduction = 0.65f;
    [SerializeField, Range(0f, 1f)] private float lifeSteal = 0.1f;

    [Header("Phase Transition Lasers")]
    [SerializeField, Range(1, 16)] private int phaseLaserCount = 6;

    private const float LaserWidth = 0.55f;
    private const float LaserFireTime = 0.6f;
    private const float FollowUpWidth = 0.4f;
    private const float LaserFadeTime = 0.22f;
    private const float SlashWidth = 1.25f;
    private const float SlashFadeTime = 0.32f;
    private const float PhaseLaserWidth = 0.65f;
    private const float PhaseWarningTime = 0.75f;
    private static readonly Color LaserColor = new Color(1f, 0.17f, 0.11f, 1f);
    private static readonly Color PhaseLaserColor = new Color(1f, 0.37f, 0.17f, 1f);
    private static readonly int Moving = Animator.StringToHash("Moving");
    private static readonly int Idle = Animator.StringToHash("Base Layer.Idle");
    private static readonly int Laser = Animator.StringToHash("Base Layer.Laser");
    private static readonly int Slash = Animator.StringToHash("Base Layer.Slash");

    private readonly HashSet<Enemy> slashTargets = new();
    private sealed class BeamEffect
    {
        public LineRenderer Line;
        public Color Color;
        public float Width;
        public float Duration;
        public float Elapsed;
    }

    private readonly BeamEffect primaryBeam = new();
    private readonly BeamEffect followUpBeam = new();
    private BeamEffect[] phaseBeams;
    private Vector3[] phaseLaserCenters;
    private Rigidbody2D body;
    private Coroutine pattern;
    private LineRenderer attackLine;
    private Material lineMaterial;
    private Vector3 lineStart;
    private Vector3 lineEnd;
    private float patternTimer;
    private bool hidden;
    private bool firingLasers;
    private bool isPhaseTwo;
    private bool followUpArmed;
    private bool transitioningPhase;

    protected override bool UsesWaveStatMultiplier => false;
    private float LaserSpeed => isPhaseTwo ? 1.5f : 1f;
    private float PatternSpeed => isPhaseTwo ? 1.5f : 1f;
    private float CurrentPatternSpeed => transitioningPhase ? 1f : firingLasers ? LaserSpeed : PatternSpeed;

    protected override void Awake()
    {
        base.Awake();
        body = GetComponent<Rigidbody2D>();
        CreateAttackLine();
    }

    protected override void OnEnable()
    {
        base.OnEnable();
        patternTimer = timeBetweenPatterns;
        isPhaseTwo = false;
    }

    protected override void Update()
    {
        if (IsDead || PlayerTransform == null)
            return;

        if (pattern != null)
        {
            animator.speed = CurrentPatternSpeed;
            return;
        }

        patternTimer -= Time.deltaTime * PatternSpeed;
        if (patternTimer <= 0f && !IsAttacking && !IsKnockedBack)
        {
            pattern = StartCoroutine(RunPattern());
            return;
        }

        base.Update();
        animator.SetBool(Moving, !IsAttacking && body.linearVelocity.sqrMagnitude > 0.01f);
    }

    public override void TakeDamage(float damage, Vector2 hitDirection)
    {
        if (!hidden)
        {
            base.TakeDamage(pattern != null ? damage * (1f - patternDamageReduction) : damage, Vector2.zero);
            if (!IsDead && !isPhaseTwo && CurrentHealth <= MaxHealth * 0.5f)
                BeginPhaseTwo();
        }
    }

    protected override void HitPlayer(Player player, float damage)
    {
        DamagePlayerAndHeal(player, damage, meleeHealthDamagePercent);
    }

    private float DamagePlayerAndHeal(Player player, float damage, float healthDamagePercent)
    {
        float appliedDamage = player.ApplyDamage(damage + player.MaxHealth * (healthDamagePercent / 100f));
        RestoreHealth(appliedDamage * lifeSteal);
        return appliedDamage;
    }

    private IEnumerator RunPattern()
    {
        CancelKnockback();
        animator.SetBool(Moving, false);
        firingLasers = true;
        animator.speed = LaserSpeed;
        // Phase two fires two lasers per swing.
        int swings = isPhaseTwo ? 3 : 4;
        for (int swing = 0; swing < swings; swing++)
        {
            followUpArmed = false;
            PrepareLaser(LaserFireTime / LaserSpeed);
            animator.Play(Laser, 0, 0f);
            yield return WaitForPatternTime(isPhaseTwo ? 1.06f : 0.84f);
            HideLine();
            if (PlayerTransform == null)
            {
                ResetPattern();
                yield break;
            }
        }

        firingLasers = false;
        animator.speed = PatternSpeed;
        hidden = true;
        visual.enabled = false;
        SetCollidersEnabled(false);
        yield return WaitForPatternTime(0.45f);

        if (PlayerTransform != null)
        {
            Vector3 target = PlayerTransform.position;
            float side = Random.value < 0.5f ? -1f : 1f;
            body.position = (Vector2)target + Vector2.right * (2.5f * side);
            transform.position = new Vector3(body.position.x, body.position.y, transform.position.z);
            SetCollidersEnabled(true);
            visual.enabled = true;
            hidden = false;
            UpdateFacing(Vector2.left * side);

            AimLine(transform.position, Vector2.right);
            ShowLine(0.12f, new Color(1f, 0.52f, 0.16f, 0.65f));
            animator.Play(Slash, 0, 0f);
            yield return WaitForPatternTime(0.96f);
        }

        ResetPattern();
    }

    private void BeginPhaseTwo()
    {
        isPhaseTwo = true;
        CancelPattern();
        CancelMeleeAttack();
        CancelKnockback();
        animator.SetBool(Moving, false);
        animator.speed = 1f;
        animator.Play(Idle, 0, 0f);
        transitioningPhase = true;
        pattern = StartCoroutine(RunPhaseTransition());
    }

    private IEnumerator RunPhaseTransition()
    {
        PreparePhaseLasers(Vector2.up);
        yield return new WaitForSeconds(PhaseWarningTime);
        FirePhaseLasers(Vector2.up);

        yield return new WaitForSeconds(1f - PhaseWarningTime);
        PreparePhaseLasers(Vector2.right);
        yield return new WaitForSeconds(PhaseWarningTime);
        FirePhaseLasers(Vector2.right);

        yield return new WaitForSeconds(LaserFadeTime);
        ResetPattern();
    }

    private void PreparePhaseLasers(Vector2 direction)
    {
        Camera camera = Camera.main;
        bool vertical = direction == Vector2.up;
        Vector3 fallbackAxis = vertical ? Vector3.right : Vector3.up;
        for (int i = 0; i < phaseBeams.Length; i++)
        {
            float fraction = (i + 1f) / (phaseBeams.Length + 1f);
            Vector3 center = transform.position + fallbackAxis * ((fraction - 0.5f) * 18f);
            if (camera != null && camera.orthographic)
            {
                float depth = camera.WorldToViewportPoint(transform.position).z;
                center = camera.ViewportToWorldPoint(
                    new Vector3(vertical ? fraction : 0.5f, vertical ? 0.5f : fraction, depth));
            }

            phaseLaserCenters[i] = center;
            AimLine(center, direction);
            BeamEffect beam = phaseBeams[i];
            beam.Duration = 0f;
            if (beam.Line != null)
                DrawLine(beam.Line, 0.1f, new Color(1f, 0.44f, 0.16f, 0.7f));
        }
    }

    private void FirePhaseLasers(Vector2 direction)
    {
        GameplaySfx.Play(GameplaySound.BossPhaseBurst);
        bool damagedPlayer = false;
        for (int i = 0; i < phaseBeams.Length; i++)
        {
            AimLine(phaseLaserCenters[i], direction);
            ShowBeam(phaseBeams[i], PhaseLaserWidth, PhaseLaserColor, LaserFadeTime);
            if (!damagedPlayer)
                damagedPlayer = DamageAlongLine(PhaseLaserWidth, laserDamage, laserHealthDamagePercent, false, 30f);
        }
    }

    private void PrepareLaser(float timeUntilFire)
    {
        Vector3 target = PredictLaserTarget(timeUntilFire);
        float angle = Random.Range(0f, 360f) * Mathf.Deg2Rad;
        Vector2 direction = new Vector2(Mathf.Cos(angle), Mathf.Sin(angle));
        UpdateFacing((Vector2)(target - transform.position));
        AimLine(target, direction);
        ShowLine(0.09f, new Color(1f, 0.2f, 0.12f, 0.55f));
    }

    private Vector3 PredictLaserTarget(float timeUntilFire)
    {
        Vector3 target = PlayerTransform.position;
        if (PlayerTarget.TryGetComponent<Rigidbody2D>(out var playerBody))
        {
            Vector2 lead = playerBody.linearVelocity * timeUntilFire;
            target += (Vector3)Vector2.ClampMagnitude(lead, 4f);
        }
        return target;
    }

    private IEnumerator WaitForPatternTime(float duration)
    {
        while (duration > 0f)
        {
            yield return null;
            duration -= Time.deltaTime * CurrentPatternSpeed;
        }
    }

    public void AnimationEvent_BossLaser()
    {
        if (pattern == null || IsDead || !firingLasers)
            return;

        FireLaser(primaryBeam, LaserWidth);
        followUpArmed = isPhaseTwo && PlayerTransform != null;
        if (followUpArmed)
            PrepareLaser(0f);
    }

    public void AnimationEvent_BossLaserFollowUp()
    {
        if (pattern == null || IsDead || !firingLasers || !followUpArmed)
            return;

        followUpArmed = false;
        FireLaser(followUpBeam, FollowUpWidth);
    }

    private void FireLaser(BeamEffect beam, float width)
    {
        GameplaySfx.Play(GameplaySound.BossLaser);
        ShowBeam(beam, width, LaserColor, LaserFadeTime);
        DamageAlongLine(width, laserDamage, laserHealthDamagePercent, false, 24f);
    }

    public void AnimationEvent_BossSlash()
    {
        if (pattern == null || IsDead || firingLasers || transitioningPhase)
            return;

        GameplaySfx.Play(GameplaySound.BossSlash);
        ShowBeam(primaryBeam, SlashWidth, new Color(1f, 0.76f, 0.3f, 0.9f), SlashFadeTime);
        DamageAlongLine(SlashWidth, slashDamage, slashHealthDamagePercent, true, 52f);
    }

    private void PlayCameraImpact(float strength)
    {
        if (PlayerTarget != null && PlayerTarget.TryGetComponent<PlayerHitFeedback>(out var feedback))
            feedback.PlayImpact(strength);
    }

    private void AimLine(Vector3 center, Vector2 direction)
    {
        center.z = transform.position.z;
        Camera camera = Camera.main;
        float reach = 32f;
        if (camera != null && camera.orthographic)
        {
            float viewRadius = camera.orthographicSize * Mathf.Sqrt(1f + camera.aspect * camera.aspect);
            reach = Vector2.Distance(center, camera.transform.position) + viewRadius + 2f;
        }

        lineStart = center - (Vector3)direction * reach;
        lineEnd = center + (Vector3)direction * reach;
    }

    private bool DamageAlongLine(float width, float damage, float healthDamagePercent, bool killEnemies, float impactStrength)
    {
        Vector2 axis = lineEnd - lineStart;
        float angle = Mathf.Atan2(axis.y, axis.x) * Mathf.Rad2Deg;
        Collider2D[] hits = Physics2D.OverlapBoxAll((lineStart + lineEnd) * 0.5f, new Vector2(axis.magnitude, width), angle);
        Player hitPlayer = null;
        slashTargets.Clear();
        foreach (Collider2D hit in hits)
        {
            if (PlayerTarget != null && hit == PlayerTarget.BodyCollider)
                hitPlayer = PlayerTarget;

            if (killEnemies)
            {
                Enemy enemy = hit.GetComponentInParent<Enemy>();
                if (enemy != null && enemy != this)
                    slashTargets.Add(enemy);
            }
        }

        bool damagedPlayer = hitPlayer != null && DamagePlayerAndHeal(hitPlayer, damage, healthDamagePercent) > 0f;
        if (damagedPlayer)
            PlayCameraImpact(impactStrength);

        foreach (Enemy enemy in slashTargets)
        {
            if (enemy != null && enemy.isActiveAndEnabled)
                enemy.KillByBossSlash();
        }
        slashTargets.Clear();
        return damagedPlayer;
    }

    private void CreateAttackLine()
    {
        int count = Mathf.Clamp(phaseLaserCount, 1, 16);
        phaseBeams = new BeamEffect[count];
        phaseLaserCenters = new Vector3[count];
        for (int i = 0; i < phaseBeams.Length; i++)
            phaseBeams[i] = new BeamEffect();

        Shader shader = Shader.Find("Sprites/Default");
        if (shader == null)
            return;

        lineMaterial = new Material(shader);
        attackLine = CreateLine("Boss Attack Warning");
        primaryBeam.Line = CreateLine("Boss Attack Beam");
        followUpBeam.Line = CreateLine("Boss Follow-up Beam");
        foreach (BeamEffect beam in phaseBeams)
            beam.Line = CreateLine("Boss Phase Beam");
    }

    private LineRenderer CreateLine(string name)
    {
        GameObject line = new GameObject(name);
        line.transform.SetParent(transform, false);
        var renderer = line.AddComponent<LineRenderer>();
        renderer.sharedMaterial = lineMaterial;
        renderer.useWorldSpace = true;
        renderer.positionCount = 2;
        renderer.sortingOrder = 6;
        renderer.enabled = false;
        return renderer;
    }

    private void ShowLine(float width, Color color)
    {
        if (attackLine == null)
            return;

        DrawLine(attackLine, width, color);
    }

    private void ShowBeam(BeamEffect beam, float width, Color color, float duration)
    {
        HideLine();
        if (beam.Line == null)
            return;

        beam.Width = width;
        beam.Color = color;
        beam.Duration = duration;
        beam.Elapsed = 0f;
        DrawLine(beam.Line, width, color);
    }

    private void DrawLine(LineRenderer line, float width, Color color)
    {
        line.SetPosition(0, lineStart);
        line.SetPosition(1, lineEnd);
        line.widthMultiplier = width;
        line.startColor = color;
        line.endColor = color;
        line.enabled = true;
    }

    private void LateUpdate()
    {
        FadeBeam(primaryBeam);
        FadeBeam(followUpBeam);
        foreach (BeamEffect beam in phaseBeams)
            FadeBeam(beam);
    }

    private static void FadeBeam(BeamEffect beam)
    {
        if (beam.Line == null || !beam.Line.enabled || beam.Duration <= 0f)
            return;

        beam.Elapsed += Time.deltaTime;
        float remaining = 1f - Mathf.Clamp01(beam.Elapsed / beam.Duration);
        beam.Line.widthMultiplier = beam.Width * remaining;
        Color color = beam.Color;
        color.a *= remaining;
        beam.Line.startColor = color;
        beam.Line.endColor = color;
        if (remaining <= 0f)
            beam.Line.enabled = false;
    }

    private void HideLine()
    {
        if (attackLine != null)
            attackLine.enabled = false;
    }

    private void ResetPattern()
    {
        if (hidden)
        {
            hidden = false;
            visual.enabled = true;
            SetCollidersEnabled(true);
        }
        HideLine();
        firingLasers = false;
        followUpArmed = false;
        transitioningPhase = false;
        animator.speed = 1f;
        if (animator.isActiveAndEnabled)
            animator.Play(Idle, 0, 0f);
        patternTimer = timeBetweenPatterns;
        pattern = null;
    }

    protected override void Die(DeathType deathType = DeathType.Normal)
    {
        CancelPattern();
        base.Die(deathType);
    }

    protected override void OnDisable()
    {
        CancelPattern();
        base.OnDisable();
    }

    private void CancelPattern()
    {
        if (primaryBeam.Line != null)
            primaryBeam.Line.enabled = false;
        if (followUpBeam.Line != null)
            followUpBeam.Line.enabled = false;
        foreach (BeamEffect beam in phaseBeams)
        {
            if (beam.Line != null)
                beam.Line.enabled = false;
        }

        if (pattern == null)
            return;

        StopCoroutine(pattern);
        ResetPattern();
    }

    private void OnDestroy()
    {
        if (lineMaterial != null)
            Destroy(lineMaterial);
    }
}
